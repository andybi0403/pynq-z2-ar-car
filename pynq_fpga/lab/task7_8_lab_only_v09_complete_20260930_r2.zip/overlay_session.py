"""Verified Overlay attachment and an OS lock for the single device owner.

    A matching filename is insufficient if files were replaced in place.
    Attachment also checks our recorded hashes and PYNQ's device timestamp.
    State files are evidence of identity, never evidence of a live process;
    process ownership uses an operating-system lock, released on exit/crash.
"""
import hashlib
import json
import os
from pathlib import Path
import tempfile


def artifact_identity(bitfile, hwhfile):
    def digest(path):
        h = hashlib.sha256()
        with Path(path).open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    return {"bit_path": str(Path(bitfile).resolve()),
            "bit_sha256": digest(bitfile), "hwh_sha256": digest(hwhfile)}


class DeviceLease:
    """Nonblocking process lock; a leftover file never means a live owner."""
    def __init__(self, path=None):
        self.path = Path(path or Path(tempfile.gettempdir()) / "pynq_car_device.lock")
        self.stream = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.stream = self.path.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt
                self.stream.seek(0)
                if self.path.stat().st_size == 0:
                    self.stream.write(b"0")
                    self.stream.flush()
                self.stream.seek(0)
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.stream.close()
            self.stream = None
            raise RuntimeError("another process owns the car Overlay/UART session") from exc
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.stream is not None:
            if os.name == "nt":
                import msvcrt
                self.stream.seek(0)
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_UN)
            self.stream.close()
            self.stream = None
        return False


def open_verified_overlay(bitfile, hwhfile, *, download=None,
                          overlay_factory=None, state_path=None):
    """Auto: reuse a verified matching load; download only when not loaded.

    download=False strictly attaches. download=True explicitly reloads and
    resets all PL calibration/leases. Caller must hold DeviceLease throughout
    hardware use; this helper intentionally does not release ownership early.
    """
    identity = artifact_identity(bitfile, hwhfile)
    if overlay_factory is None:
        try:
            from pynq import Overlay
        except ImportError as exc:
            raise RuntimeError("PYNQ package unavailable; run on PYNQ-Z2") from exc
        overlay_factory = Overlay
    state_path = Path(state_path or Path(tempfile.gettempdir()) / "pynq_car_overlay_identity.json")
    overlay = overlay_factory(str(Path(bitfile).resolve()), download=False)
    loaded = overlay.is_loaded()
    if download is True or (download is None and not loaded):
        overlay.download()
        identity["device_timestamp"] = str(overlay.device.timestamp)
        state_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = state_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(identity, sort_keys=True), encoding="utf-8")
        temporary.replace(state_path)
    else:
        if not loaded:
            raise RuntimeError("requested Overlay is not loaded; attachment refused")
        try:
            recorded = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise RuntimeError("loaded Overlay identity is missing; explicit reload required") from exc
        identity["device_timestamp"] = str(overlay.device.timestamp)
        if recorded != identity:
            raise RuntimeError("loaded Overlay hashes/timestamp differ; explicit reload required")
    if not overlay.is_loaded():
        raise RuntimeError("Overlay download/attachment could not be verified")
    return overlay
